-- RIVERA database schema. Run this entire file in Supabase SQL Editor.
-- IMPORTANT: The first account must be promoted manually to administrator (see README).

create extension if not exists pgcrypto;

create table if not exists public.ranks (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  permissions jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  status text not null default 'pending' check (status in ('pending','active','disabled','rejected')),
  is_admin boolean not null default false,
  rank_id uuid references public.ranks(id) on delete set null,
  permissions jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.inventory_items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  unit text not null default 'Stück',
  warehouse text not null check (warehouse in ('leaders','main','equipment')),
  note text not null default '',
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.inventory_entries (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.inventory_items(id),
  kind text not null check (kind in ('in','out')),
  quantity numeric(14,2) not null check (quantity > 0),
  note text not null default '',
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create index if not exists inventory_entries_item_idx on public.inventory_entries(item_id);
create index if not exists inventory_entries_created_idx on public.inventory_entries(created_at desc);
create index if not exists profiles_status_idx on public.profiles(status);

create or replace function public.is_active_user()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles where id = auth.uid() and status = 'active') $$;

create or replace function public.is_admin_user()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    left join public.ranks r on r.id = p.rank_id
    where p.id = auth.uid() and p.status = 'active'
      and (p.is_admin
        or coalesce((p.permissions ->> 'can_admin')::boolean, false)
        or coalesce((r.permissions ->> 'can_admin')::boolean, false))
  )
$$;

create or replace function public.has_permission(permission_key text)
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    left join public.ranks r on r.id = p.rank_id
    where p.id = auth.uid() and p.status = 'active'
      and (p.is_admin or coalesce((p.permissions ->> permission_key)::boolean, false)
           or coalesce((r.permissions ->> permission_key)::boolean, false))
  )
$$;

create or replace function public.can_access_warehouse(warehouse_key text)
returns boolean language sql stable security definer set search_path = public
as $$ select public.is_admin_user() or public.has_permission('can_' || warehouse_key) $$;

alter table public.ranks enable row level security;
alter table public.profiles enable row level security;
alter table public.inventory_items enable row level security;
alter table public.inventory_entries enable row level security;

-- Ranks are visible to active users; only admins create/edit/delete them.
drop policy if exists "active users read ranks" on public.ranks;
create policy "active users read ranks" on public.ranks for select using (public.is_active_user());
drop policy if exists "admins manage ranks" on public.ranks;
create policy "admins manage ranks" on public.ranks for all using (public.is_admin_user()) with check (public.is_admin_user());

-- Members can read active profiles; admins can read/manage all profiles.
drop policy if exists "profiles read permitted" on public.profiles;
create policy "profiles read permitted" on public.profiles for select using (
  id = auth.uid() or public.is_admin_user() or (public.is_active_user() and public.has_permission('can_members'))
);
drop policy if exists "user creates own pending profile" on public.profiles;
create policy "user creates own pending profile" on public.profiles for insert with check (
  id = auth.uid() and status = 'pending' and is_admin = false
);
drop policy if exists "admins update profiles" on public.profiles;
create policy "admins update profiles" on public.profiles for update using (public.is_admin_user()) with check (public.is_admin_user());

-- Warehouse data: access is checked by warehouse-specific permission.
drop policy if exists "read permitted inventory items" on public.inventory_items;
create policy "read permitted inventory items" on public.inventory_items for select using (public.can_access_warehouse(warehouse));
drop policy if exists "create permitted inventory items" on public.inventory_items;
create policy "create permitted inventory items" on public.inventory_items for insert with check (
  public.can_access_warehouse(warehouse) and (public.is_admin_user() or public.has_permission('can_book'))
);
drop policy if exists "admins update items" on public.inventory_items;
create policy "admins update items" on public.inventory_items for update using (public.is_admin_user()) with check (public.is_admin_user());
drop policy if exists "admins delete items" on public.inventory_items;
create policy "admins delete items" on public.inventory_items for delete using (public.is_admin_user());

drop policy if exists "read permitted entries" on public.inventory_entries;
create policy "read permitted entries" on public.inventory_entries for select using (
  exists (select 1 from public.inventory_items i where i.id = item_id and public.can_access_warehouse(i.warehouse))
);
drop policy if exists "create permitted entries" on public.inventory_entries;
create policy "create permitted entries" on public.inventory_entries for insert with check (
  created_by = auth.uid()
  and exists (select 1 from public.inventory_items i where i.id = item_id and public.can_access_warehouse(i.warehouse))
  and (public.is_admin_user() or public.has_permission('can_book'))
);
-- Ledger entries are immutable to preserve audit history. Corrections should be new counter-bookings.

-- Enable realtime for inventory and member status updates.
do $$ begin
  alter publication supabase_realtime add table public.inventory_items;
exception when duplicate_object then null; when others then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.inventory_entries;
exception when duplicate_object then null; when others then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.profiles;
exception when duplicate_object then null; when others then null; end $$;

-- SECURITY NOTE:
-- Supabase Auth users sign up with an internal username-derived email alias.
-- Use only usernames without spaces/special characters in this starter implementation.
-- Do not expose a service_role key in the frontend or GitHub Pages.
