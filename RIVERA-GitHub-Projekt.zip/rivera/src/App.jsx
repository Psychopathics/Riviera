import React, { useEffect, useMemo, useState } from 'react'
import {
  Shield, Users, Warehouse, Package, Tent, LogOut, Plus, Check, X,
  ArrowDownToLine, ArrowUpFromLine, RefreshCw, Crown, Menu, LayoutDashboard,
  Settings, History, Search, LockKeyhole, UserRound, Clock3, AlertCircle
} from 'lucide-react'
import { supabase } from './supabase'

const areas = [
  { id: 'dashboard', label: 'Übersicht', icon: LayoutDashboard },
  { id: 'admin', label: 'Adminbereich', icon: Shield },
  { id: 'leaders', label: 'Leaderschaftslager', icon: Tent },
  { id: 'main', label: 'Hauptlager', icon: Warehouse },
  { id: 'equipment', label: 'Waffenlager', icon: Package },
  { id: 'members', label: 'Mitglieder', icon: Users },
  { id: 'protocol', label: 'Protokoll', icon: History },
]

const warehouseNames = { leaders: 'Leaderschaftslager', main: 'Hauptlager', equipment: 'Waffenlager' }
const prettyDate = value => new Date(value).toLocaleString('de-DE', { dateStyle: 'short', timeStyle: 'short' })

export default function App() {
  const [session, setSession] = useState(null)
  const [profile, setProfile] = useState(null)
  const [page, setPage] = useState('dashboard')
  const [authMode, setAuthMode] = useState('login')
  const [authName, setAuthName] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState('')
  const [members, setMembers] = useState([])
  const [ranks, setRanks] = useState([])
  const [items, setItems] = useState([])
  const [entries, setEntries] = useState([])
  const [pending, setPending] = useState([])
  const [mobileNav, setMobileNav] = useState(false)
  const [search, setSearch] = useState('')
  const [showNewItem, setShowNewItem] = useState(false)
  const [showEntry, setShowEntry] = useState(false)
  const [newRank, setNewRank] = useState('')
  const [rankPerm, setRankPerm] = useState({ can_admin: false, can_leaders: false, can_main: false, can_equipment: false, can_members: false, can_protocol: false, can_book: false })
  const [itemForm, setItemForm] = useState({ name: '', unit: 'Stück', warehouse: 'main', note: '' })
  const [entryForm, setEntryForm] = useState({ item_id: '', kind: 'in', quantity: 1, note: '' })

  useEffect(() => {
    if (!supabase) return
    supabase.auth.getSession().then(({ data }) => setSession(data.session))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next))
    return () => listener.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (session?.user) loadData()
    else { setProfile(null); setMembers([]); setRanks([]); setItems([]); setEntries([]) }
  }, [session])

  async function loadData() {
    const uid = session.user.id
    const [p, m, r, i, e] = await Promise.all([
      supabase.from('profiles').select('*, ranks(*)').eq('id', uid).maybeSingle(),
      supabase.from('profiles').select('*, ranks(*)').order('created_at'),
      supabase.from('ranks').select('*').order('name'),
      supabase.from('inventory_items').select('*').order('name'),
      supabase.from('inventory_entries').select('*, inventory_items(name, warehouse), profiles(display_name)').order('created_at', { ascending: false }).limit(250)
    ])
    if (p.error) setNotice(p.error.message)
    setProfile(p.data)
    setMembers(m.data || [])
    setRanks(r.data || [])
    setItems(i.data || [])
    setEntries(e.data || [])
    if (p.data?.is_admin || p.data?.permissions?.can_admin) {
      const { data } = await supabase.from('profiles').select('*, ranks(*)').eq('status', 'pending').order('created_at')
      setPending(data || [])
    } else setPending([])
  }

  useEffect(() => {
    if (!supabase || !session) return
    const channel = supabase.channel('rivera-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'inventory_items' }, loadData)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'inventory_entries' }, loadData)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, loadData)
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [session, profile?.id])

  const permissions = profile?.permissions || {}
  const rankPermissions = profile?.ranks?.permissions || {}
  const isAdmin = !!(profile?.is_admin || permissions.can_admin || rankPermissions.can_admin)
  const hasPermission = key => isAdmin || !!permissions[key] || !!rankPermissions[key]
  const canSee = id => id === 'dashboard' || (id === 'admin' && isAdmin) ||
    (id === 'members' && hasPermission('can_members')) ||
    (id === 'protocol' && hasPermission('can_protocol')) ||
    (id === 'leaders' && hasPermission('can_leaders')) ||
    (id === 'main' && hasPermission('can_main')) ||
    (id === 'equipment' && hasPermission('can_equipment'))
  const visibleAreas = areas.filter(a => canSee(a.id))
  const warehouseForPage = page === 'leaders' ? 'leaders' : page === 'equipment' ? 'equipment' : 'main'
  const canBook = hasPermission('can_book') || hasPermission(`can_${warehouseForPage}_book`)

  async function authenticate(event) {
    event.preventDefault(); setBusy(true); setNotice('')
    try {
      if (!supabase) throw new Error('Supabase ist noch nicht konfiguriert. Bitte .env bzw. GitHub-Secrets einrichten.')
      const email = `${authName.trim().toLowerCase().replace(/[^a-z0-9._-]/g, '')}@rivera.local`
      if (authMode === 'register') {
        const { data, error } = await supabase.auth.signUp({ email, password })
        if (error) throw error
        if (data.user) {
          const { error: insertError } = await supabase.from('profiles').insert({ id: data.user.id, display_name: authName.trim(), status: 'pending' })
          if (insertError) throw insertError
        }
        setNotice('Registrierung eingereicht. Dein Zugang wird nach der Freigabe durch den Admin aktiviert.')
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
      }
    } catch (e) { setNotice(e.message || 'Es ist ein Fehler aufgetreten.') }
    finally { setBusy(false) }
  }

  async function signOut() { await supabase.auth.signOut(); setPage('dashboard') }
  async function approveMember(id, approve) {
    const { error } = await supabase.from('profiles').update({ status: approve ? 'active' : 'rejected' }).eq('id', id)
    setNotice(error ? error.message : (approve ? 'Mitglied freigegeben.' : 'Registrierung abgelehnt.'))
    loadData()
  }
  async function assignRank(memberId, rankId) {
    const { error } = await supabase.from('profiles').update({ rank_id: rankId || null }).eq('id', memberId)
    setNotice(error ? error.message : 'Rang aktualisiert.'); loadData()
  }
  async function toggleMember(member) {
    const { error } = await supabase.from('profiles').update({ status: member.status === 'active' ? 'disabled' : 'active' }).eq('id', member.id)
    setNotice(error ? error.message : 'Mitgliederstatus aktualisiert.'); loadData()
  }
  async function createRank(e) {
    e.preventDefault()
    const { error } = await supabase.from('ranks').insert({ name: newRank.trim(), permissions: rankPerm })
    setNotice(error ? error.message : 'Rang erstellt.'); setNewRank(''); loadData()
  }
  async function createItem(e) {
    e.preventDefault()
    const { error } = await supabase.from('inventory_items').insert({ ...itemForm, name: itemForm.name.trim(), created_by: session.user.id })
    setNotice(error ? error.message : 'Artikel angelegt.'); setShowNewItem(false); setItemForm({ name: '', unit: 'Stück', warehouse: warehouseForPage, note: '' }); loadData()
  }
  async function createEntry(e) {
    e.preventDefault()
    const quantity = Number(entryForm.quantity)
    if (!entryForm.item_id || !Number.isFinite(quantity) || quantity <= 0) { setNotice('Bitte Artikel und eine gültige Menge angeben.'); return }
    const { error } = await supabase.from('inventory_entries').insert({ item_id: entryForm.item_id, kind: entryForm.kind, quantity, note: entryForm.note.trim(), created_by: session.user.id })
    setNotice(error ? error.message : 'Lagerbuchung gespeichert.'); setShowEntry(false); setEntryForm({ item_id: '', kind: 'in', quantity: 1, note: '' }); loadData()
  }
  async function savePermissions(member, next) {
    const { error } = await supabase.from('profiles').update({ permissions: next }).eq('id', member.id)
    setNotice(error ? error.message : 'Berechtigungen gespeichert.'); loadData()
  }

  const stock = useMemo(() => {
    const map = {}
    for (const item of items) map[item.id] = 0
    for (const entry of entries) if (map[entry.item_id] !== undefined) map[entry.item_id] += entry.kind === 'in' ? Number(entry.quantity) : -Number(entry.quantity)
    return map
  }, [items, entries])
  const currentItems = items.filter(i => i.warehouse === warehouseForPage && i.name.toLowerCase().includes(search.toLowerCase()))
  const currentEntries = entries.filter(e => e.inventory_items?.warehouse === warehouseForPage)
  const activeMembers = members.filter(m => m.status === 'active')

  if (!session) return <AuthScreen mode={authMode} setMode={setAuthMode} name={authName} setName={setAuthName} password={password} setPassword={setPassword} onSubmit={authenticate} busy={busy} notice={notice} configured={!!supabase} />

  if (!profile) return <div className="loading"><div className="brand-mark">R</div><p>RIVERA wird geladen …</p></div>
  if (profile.status !== 'active') return <div className="auth-shell"><div className="auth-card"><div className="brand-mark">R</div><p className="eyebrow">RIVERA MEMBER SYSTEM</p><h1>Zugang noch nicht freigegeben</h1><p className="muted">Dein Konto wartet auf die Genehmigung durch einen Administrator oder wurde deaktiviert.</p><button className="btn secondary full" onClick={signOut}>Abmelden</button></div></div>

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? 'open' : ''}`}>
      <div className="brand"><div className="brand-mark small">R</div><div><b>RIVERA</b><span>MEMBER SYSTEM</span></div></div>
      <div className="nav-label">MENÜ</div>
      {visibleAreas.map(a => <button key={a.id} className={`nav-item ${page === a.id ? 'selected' : ''}`} onClick={() => { setPage(a.id); setMobileNav(false) }}><a.icon size={18}/><span>{a.label}</span>{a.id === 'admin' && pending.length > 0 && <i className="count">{pending.length}</i>}</button>)}
      <div className="sidebar-bottom"><div className="user-mini"><div className="avatar">{profile.display_name?.[0]?.toUpperCase() || 'R'}</div><div><b>{profile.display_name}</b><span>{profile.ranks?.name || (isAdmin ? 'Administrator' : 'Mitglied')}</span></div></div><button className="nav-item logout" onClick={signOut}><LogOut size={17}/>Abmelden</button></div>
    </aside>
    <main className="main">
      <header className="topbar"><button className="icon-btn mobile-only" onClick={() => setMobileNav(!mobileNav)}><Menu/></button><div><p className="eyebrow">RIVERA / INTERN</p><h1>{areas.find(a => a.id === page)?.label || 'Übersicht'}</h1></div><div className="top-actions"><span className="live-dot"/> Live-System <div className="avatar">{profile.display_name?.[0]?.toUpperCase()}</div></div></header>
      {notice && <div className="notice"><AlertCircle size={16}/>{notice}<button onClick={() => setNotice('')}><X size={15}/></button></div>}
      {page === 'dashboard' && <Dashboard profile={profile} members={activeMembers} items={items} stock={stock} entries={entries} setPage={setPage} canSee={canSee}/>}
      {page === 'admin' && isAdmin && <Admin pending={pending} members={members} ranks={ranks} newRank={newRank} setNewRank={setNewRank} rankPerm={rankPerm} setRankPerm={setRankPerm} createRank={createRank} approveMember={approveMember} assignRank={assignRank} toggleMember={toggleMember} savePermissions={savePermissions}/>}
      {['leaders','main','equipment'].includes(page) && <WarehousePage title={warehouseNames[page]} items={currentItems} stock={stock} entries={currentEntries} canBook={canBook} showNewItem={showNewItem} setShowNewItem={setShowNewItem} showEntry={showEntry} setShowEntry={setShowEntry} itemForm={itemForm} setItemForm={setItemForm} entryForm={entryForm} setEntryForm={setEntryForm} createItem={createItem} createEntry={createEntry} search={search} setSearch={setSearch} warehouse={warehouseForPage}/>}
      {page === 'members' && <Members members={activeMembers} ranks={ranks} search={search} setSearch={setSearch}/>}
      {page === 'protocol' && <Protocol entries={entries}/>}
    </main>
  </div>
}

function AuthScreen({ mode, setMode, name, setName, password, setPassword, onSubmit, busy, notice, configured }) {
  return <div className="auth-shell"><div className="auth-glow"/><form className="auth-card" onSubmit={onSubmit}><div className="brand-mark">R</div><p className="eyebrow">MEMBER MANAGEMENT SYSTEM</p><h1>Willkommen bei <em>RIVERA</em></h1><p className="muted">Der interne Zugang für Mitglieder und Verwaltung.</p>
    {!configured && <div className="warning"><AlertCircle size={17}/> Supabase-Konfiguration fehlt. Bitte Projekt einrichten und Umgebungsvariablen setzen.</div>}
    <label>Benutzername<input required minLength="2" value={name} onChange={e => setName(e.target.value)} placeholder="Dein Name" autoComplete="username"/></label>
    <label>Passwort<input required minLength="8" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Mindestens 8 Zeichen" autoComplete={mode === 'login' ? 'current-password' : 'new-password'}/></label>
    {notice && <div className="notice">{notice}</div>}
    <button className="btn gold full" disabled={busy || !configured}>{busy ? 'Bitte warten …' : mode === 'login' ? 'Anmelden' : 'Registrierung beantragen'}</button>
    <p className="switch-auth">{mode === 'login' ? 'Noch kein Konto?' : 'Bereits registriert?'} <button type="button" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Registrieren' : 'Zum Login'}</button></p>
    <div className="auth-foot">RIVERA <span>•</span> INTERNES SYSTEM</div>
  </form></div>
}

function Dashboard({ profile, members, items, stock, entries, setPage, canSee }) {
  const total = Object.values(stock).reduce((a,b) => a + b, 0)
  return <div className="content"><div className="welcome-panel"><div><p className="eyebrow">ÜBERSICHT</p><h2>Guten Tag, {profile.display_name}.</h2><p>Willkommen im internen RIVERA-System.</p></div><Crown className="welcome-icon"/></div>
    <div className="stats-grid"><Stat label="Aktive Mitglieder" value={members.length} icon={Users}/><Stat label="Artikel im Inventar" value={items.length} icon={Package}/><Stat label="Gesamtbestand" value={total} icon={Warehouse}/><Stat label="Buchungen" value={entries.length} icon={History}/></div>
    <h3 className="section-title">Bereiche</h3><div className="module-grid">{areas.filter(a => a.id !== 'dashboard' && canSee(a.id)).map(a => <button className="module-card" key={a.id} onClick={() => setPage(a.id)}><a.icon/><b>{a.label}</b><span>Bereich öffnen <span>↗</span></span></button>)}</div>
    <div className="panel"><div className="panel-head"><div><h3>Letzte Aktivitäten</h3><p>Aktuelle Lagerbuchungen</p></div><History/></div><EntryTable entries={entries.slice(0,5)}/></div>
  </div>
}
function Stat({ label, value, icon: Icon }) { return <div className="stat-card"><div className="stat-icon"><Icon size={19}/></div><span>{label}</span><b>{value}</b></div> }

function Admin({ pending, members, ranks, newRank, setNewRank, rankPerm, setRankPerm, createRank, approveMember, assignRank, toggleMember, savePermissions }) {
  const [tab, setTab] = useState('requests')
  const [editing, setEditing] = useState(null)
  const permissionLabels = [['can_admin','Adminbereich'],['can_leaders','Leaderschaftslager'],['can_main','Hauptlager'],['can_equipment','Waffenlager'],['can_members','Mitglieder'],['can_protocol','Protokoll'],['can_book','Lagerbuchungen']]
  return <div className="content"><div className="tabs">{[['requests',`Anträge (${pending.length})`],['members','Mitglieder verwalten'],['ranks','Ränge & Rechte']].map(([id,label]) => <button className={tab===id?'active':''} onClick={()=>setTab(id)} key={id}>{label}</button>)}</div>
    {tab==='requests' && <div className="panel"><div className="panel-head"><div><h3>Offene Registrierungen</h3><p>Jeder neue Zugang muss freigegeben werden.</p></div><Shield/></div>{pending.length ? pending.map(m=><div className="request-row" key={m.id}><div className="member-cell"><div className="avatar">{m.display_name?.[0]}</div><div><b>{m.display_name}</b><span>{prettyDate(m.created_at)}</span></div></div><div className="row-actions"><button className="btn small gold" onClick={()=>approveMember(m.id,true)}><Check size={15}/> Freigeben</button><button className="btn small danger" onClick={()=>approveMember(m.id,false)}><X size={15}/> Ablehnen</button></div></div>):<Empty text="Keine offenen Registrierungen."/>}</div>}
    {tab==='members' && <div className="panel"><div className="panel-head"><div><h3>Mitgliederverwaltung</h3><p>Ränge, Status und individuelle Zugriffsrechte.</p></div><Users/></div><div className="table-wrap"><table><thead><tr><th>Mitglied</th><th>Rang</th><th>Status</th><th>Aktion</th></tr></thead><tbody>{members.map(m=><tr key={m.id}><td><b>{m.display_name}</b></td><td><select value={m.rank_id||''} onChange={e=>assignRank(m.id,e.target.value)}><option value="">Ohne Rang</option>{ranks.map(r=><option value={r.id} key={r.id}>{r.name}</option>)}</select></td><td><span className={`status ${m.status}`}>{m.status}</span></td><td><button className="btn small secondary" onClick={()=>setEditing(editing===m.id?null:m.id)}><Settings size={14}/> Rechte</button> <button className="btn small danger" onClick={()=>toggleMember(m)}>{m.status==='active'?'Deaktivieren':'Aktivieren'}</button></td></tr>)}</tbody></table></div>
      {editing && <div className="permission-editor"><h4>Berechtigungen: {members.find(m=>m.id===editing)?.display_name}</h4><PermissionChecks value={members.find(m=>m.id===editing)?.permissions||{}} labels={permissionLabels} onChange={v=>savePermissions(members.find(m=>m.id===editing),v)}/></div>}
    </div>}
    {tab==='ranks' && <div className="panel"><div className="panel-head"><div><h3>Eigene Ränge erstellen</h3><p>Jeder Rang kann mit eigenen Berechtigungen ausgestattet werden.</p></div><Crown/></div><form className="rank-form" onSubmit={createRank}><input required value={newRank} onChange={e=>setNewRank(e.target.value)} placeholder="Name des neuen Rangs"/><button className="btn gold"><Plus size={16}/> Rang erstellen</button></form><h4>Berechtigungen für den neuen Rang</h4><PermissionChecks value={rankPerm} labels={permissionLabels} onChange={setRankPerm}/><div className="rank-list">{ranks.map(r=><div className="rank-chip" key={r.id}><Crown size={15}/>{r.name}</div>)}</div></div>}
  </div></div>
}

function PermissionChecks({ value, labels, onChange }) { const [draft,setDraft] = useState(value || {}); useEffect(()=>setDraft(value || {}),[JSON.stringify(value)]); return <div className="permission-grid">{labels.map(([key,label])=><label className="check-label" key={key}><input type="checkbox" checked={!!draft[key]} onChange={e=>setDraft({...draft,[key]:e.target.checked})}/>{label}</label>)}<button className="btn small gold" onClick={e=>{e.preventDefault(); onChange(draft)}}>Änderungen übernehmen</button></div> }

function WarehousePage({ title, items, stock, entries, canBook, showNewItem, setShowNewItem, showEntry, setShowEntry, itemForm, setItemForm, entryForm, setEntryForm, createItem, createEntry, search, setSearch, warehouse }) {
  const [mode,setMode] = useState('stock')
  const selectable = items
  return <div className="content"><div className="warehouse-banner"><div><p className="eyebrow">INVENTARVERWALTUNG</p><h2>{title}</h2><p>Bestände und Bewegungen zentral dokumentieren.</p></div><Warehouse size={42}/></div>
    <div className="stats-grid three"><Stat label="Artikel" value={items.length} icon={Package}/><Stat label="Gesamtbestand" value={items.reduce((a,i)=>a+(stock[i.id]||0),0)} icon={Warehouse}/><Stat label="Buchungen" value={entries.length} icon={History}/></div>
    <div className="panel"><div className="panel-head wrap"><div><h3>Bestandsübersicht</h3><p>Bestand wird aus allen Ein- und Ausgängen berechnet.</p></div><div className="toolbar"><div className="search"><Search size={15}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Artikel suchen"/></div>{canBook && <><button className="btn secondary" onClick={()=>setShowNewItem(!showNewItem)}><Plus size={15}/> Artikel</button><button className="btn gold" onClick={()=>setShowEntry(!showEntry)}><RefreshCw size={15}/> Buchung</button></>}</div></div>
      {showNewItem && <form className="inline-form" onSubmit={createItem}><input required placeholder="Artikelname" value={itemForm.name} onChange={e=>setItemForm({...itemForm,name:e.target.value,warehouse})}/><input placeholder="Einheit" value={itemForm.unit} onChange={e=>setItemForm({...itemForm,unit:e.target.value})}/><input placeholder="Bemerkung (optional)" value={itemForm.note} onChange={e=>setItemForm({...itemForm,note:e.target.value})}/><button className="btn gold">Anlegen</button></form>}
      {showEntry && <form className="inline-form" onSubmit={createEntry}><select required value={entryForm.item_id} onChange={e=>setEntryForm({...entryForm,item_id:e.target.value})}><option value="">Artikel auswählen</option>{selectable.map(i=><option value={i.id} key={i.id}>{i.name}</option>)}</select><select value={entryForm.kind} onChange={e=>setEntryForm({...entryForm,kind:e.target.value})}><option value="in">Eingang</option><option value="out">Ausgang</option></select><input required type="number" min="0.01" step="0.01" value={entryForm.quantity} onChange={e=>setEntryForm({...entryForm,quantity:e.target.value})} placeholder="Menge"/><input placeholder="Bemerkung" value={entryForm.note} onChange={e=>setEntryForm({...entryForm,note:e.target.value})}/><button className="btn gold">Speichern</button></form>}
      <div className="table-wrap"><table><thead><tr><th>Artikel</th><th>Bestand</th><th>Einheit</th><th>Bemerkung</th></tr></thead><tbody>{items.map(i=><tr key={i.id}><td><b>{i.name}</b></td><td><strong className={(stock[i.id]||0)<0?'negative':''}>{stock[i.id]||0}</strong></td><td>{i.unit||'Stück'}</td><td>{i.note||'—'}</td></tr>)}</tbody></table>{!items.length&&<Empty text="Noch keine Artikel angelegt."/ >}</div>
    </div>
    <div className="panel"><div className="panel-head"><div><h3>Bewegungsprotokoll</h3><p>Letzte Ein- und Ausgänge mit Zeit und Benutzer.</p></div><History/></div><EntryTable entries={entries.slice(0,40)}/></div>
  </div>
}

function Members({ members, ranks, search, setSearch }) { const filtered=members.filter(m=>`${m.display_name} ${m.ranks?.name||''}`.toLowerCase().includes(search.toLowerCase())); return <div className="content"><div className="panel"><div className="panel-head wrap"><div><h3>Mitgliederübersicht</h3><p>{members.length} aktive Mitglieder</p></div><div className="search"><Search size={15}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Mitglied suchen"/></div></div><div className="member-grid">{filtered.map(m=><div className="member-card" key={m.id}><div className="avatar large">{m.display_name?.[0]}</div><b>{m.display_name}</b><span className="rank-pill">{m.ranks?.name||'Ohne Rang'}</span></div>)}</div>{!filtered.length&&<Empty text="Keine Mitglieder gefunden."/>}</div></div> }
function Protocol({ entries }) { return <div className="content"><div className="panel"><div className="panel-head"><div><h3>Systemprotokoll</h3><p>Nachvollziehbare Lagerbewegungen mit Datum, Uhrzeit und Benutzer.</p></div><History/></div><EntryTable entries={entries}/></div></div> }
function EntryTable({ entries }) { return <div className="table-wrap"><table><thead><tr><th>Zeitpunkt</th><th>Artikel / Lager</th><th>Bewegung</th><th>Menge</th><th>Benutzer</th><th>Bemerkung</th></tr></thead><tbody>{entries.map(e=><tr key={e.id}><td>{prettyDate(e.created_at)}</td><td><b>{e.inventory_items?.name||'—'}</b><small>{warehouseNames[e.inventory_items?.warehouse]||''}</small></td><td><span className={`movement ${e.kind}`}>{e.kind==='in'?<><ArrowDownToLine size={13}/> Eingang</>:<><ArrowUpFromLine size={13}/> Ausgang</>}</span></td><td>{e.quantity}</td><td>{e.profiles?.display_name||'—'}</td><td>{e.note||'—'}</td></tr>)}</tbody></table>{!entries.length&&<Empty text="Noch keine Buchungen vorhanden."/>}</div> }
function Empty({ text }) { return <div className="empty"><Package size={22}/>{text}</div> }